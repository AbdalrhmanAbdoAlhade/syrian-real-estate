<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ContactMessageController extends Controller
{
    public function store(Request $request)
    {
        $data=$request->validate(['name'=>['required','string','max:120'],'phone'=>['required','string','max:40'],'email'=>['nullable','email','max:190'],'message'=>['required','string','max:5000']]);
        $message=ContactMessage::create($data);
        return response()->json(['message'=>'تم استلام رسالتك بنجاح.','id'=>$message->id],201);
    }
    public function adminIndex() { return response()->json(ContactMessage::latest()->paginate(30)); }
    public function updateStatus(Request $request, ContactMessage $contactMessage)
    {
        $data=$request->validate(['status'=>['required',Rule::in(['new','in_progress','closed'])]]);
        $contactMessage->update($data); return response()->json(['data'=>$contactMessage]);
    }
}
