<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class PropertyController extends Controller
{
    public function index(Request $request)
    {
        $query = Property::published()->latest();
        if ($request->filled('city')) $query->where('city', $request->string('city'));
        if ($request->filled('purpose')) $query->where('purpose', $request->string('purpose'));
        if ($request->filled('max_price')) $query->where('price_usd', '<=', (float)$request->input('max_price'));
        if ($request->filled('min_price')) $query->where('price_usd', '>=', (float)$request->input('min_price'));
        if ($request->filled('q')) $query->where(fn($q) => $q->where('title','like','%'.$request->input('q').'%')->orWhere('description','like','%'.$request->input('q').'%'));
        return response()->json($query->paginate(min(max((int)$request->input('per_page', 12), 1), 50)));
    }

    public function show(Property $property)
    {
        abort_unless($property->status === 'published', 404);
        return response()->json(['data' => $property]);
    }

    public function adminIndex() { return response()->json(Property::latest()->paginate(20)); }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        if ($request->hasFile('image')) $data['image'] = $request->file('image')->store('properties', 'public');
        if ($request->hasFile('images')) $data['images'] = collect($request->file('images'))->map(fn($f) => $f->store('properties', 'public'))->all();
        $data['status'] = $data['status'] ?? 'draft';
        if ($data['status'] === 'published') $data['published_at'] = now();
        $property = Property::create($data);
        return response()->json(['message'=>'تم إنشاء العقار.','data'=>$property], 201);
    }

    public function update(Request $request, Property $property)
    {
        $data = $this->validated($request, true);
        if ($request->hasFile('image')) {
            if ($property->image) Storage::disk('public')->delete($property->image);
            $data['image'] = $request->file('image')->store('properties', 'public');
        }
        if ($request->hasFile('images')) $data['images'] = collect($request->file('images'))->map(fn($f) => $f->store('properties', 'public'))->all();
        if (($data['status'] ?? null) === 'published' && !$property->published_at) $data['published_at'] = now();
        $property->update($data);
        return response()->json(['message'=>'تم تحديث العقار.','data'=>$property->fresh()]);
    }

    public function destroy(Property $property)
    {
        if ($property->image) Storage::disk('public')->delete($property->image);
        foreach (($property->images ?? []) as $image) Storage::disk('public')->delete($image);
        $property->delete();
        return response()->json(['message'=>'تم حذف العقار.']);
    }

    private function validated(Request $request, bool $partial = false): array
    {
        $required = $partial ? 'sometimes' : 'required';
        return $request->validate([
            'title'=>[$required,'string','max:190'], 'city'=>[$required,'string','max:100'],
            'district'=>['nullable','string','max:120'], 'purpose'=>[$required,Rule::in(['بيع','إيجار'])],
            'price_usd'=>[$required,'numeric','min:0'], 'area'=>[$required,'numeric','min:0'],
            'rooms'=>['nullable','integer','min:0','max:100'], 'bathrooms'=>['nullable','integer','min:0','max:100'],
            'image'=>[$partial?'sometimes':'required_without:images','nullable','image','max:5120'],
            'images'=>['sometimes','array','max:20'], 'images.*'=>['image','max:5120'],
            'description'=>[$required,'string','max:10000'], 'phone'=>['nullable','string','max:40'],
            'whatsapp'=>['nullable','string','max:40'], 'status'=>['sometimes',Rule::in(['draft','published','archived'])],
        ]);
    }
}
