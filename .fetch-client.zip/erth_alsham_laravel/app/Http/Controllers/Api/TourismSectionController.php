<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\TourismSection;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TourismSectionController extends Controller
{
    public function index() { return response()->json(TourismSection::where('is_active',true)->orderBy('sort_order')->get()); }
    public function adminIndex() { return response()->json(TourismSection::orderBy('sort_order')->get()); }
    public function store(Request $request)
    {
        $data = $this->validateData($request);
        return response()->json(['data'=>TourismSection::create($data)], 201);
    }
    public function update(Request $request, TourismSection $tourismSection)
    {
        $tourismSection->update($this->validateData($request, true, $tourismSection->id));
        return response()->json(['data'=>$tourismSection->fresh()]);
    }
    public function destroy(TourismSection $tourismSection) { $tourismSection->delete(); return response()->json(['message'=>'تم الحذف.']); }
    private function validateData(Request $request, bool $partial=false, ?int $id=null): array
    {
        $r=$partial?'sometimes':'required';
        return $request->validate([
            'slug'=>[$r,'string','max:100',Rule::unique('tourism_sections','slug')->ignore($id)],
            'title'=>[$r,'string','max:190'],'summary'=>['nullable','string','max:1000'],
            'content'=>['nullable','string','max:15000'],'icon'=>['nullable','string','max:100'],
            'sort_order'=>['sometimes','integer','min:0'],'is_active'=>['sometimes','boolean'],
        ]);
    }
}
