<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SiteSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SiteSettingController extends Controller
{
    public function index()
    {
        return response()->json(SiteSetting::all()->mapWithKeys(fn($s) => [$s->key => $this->formatValue($s)]));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'site_name'=>['sometimes','string','max:190'], 'tagline'=>['sometimes','string','max:500'],
            'phone'=>['sometimes','nullable','string','max:40'], 'whatsapp'=>['sometimes','nullable','string','max:40'],
            'email'=>['sometimes','nullable','email','max:190'], 'hero_title'=>['sometimes','string','max:500'],
            'hero_description'=>['sometimes','string','max:2000'], 'about_title'=>['sometimes','string','max:500'],
            'about_text'=>['sometimes','string','max:5000'], 'contact_text'=>['sometimes','string','max:2000'],
            'logo'=>['sometimes','image','max:3072'], 'favicon'=>['sometimes','image','max:1024'],
            'exchange_rate_syp'=>['sometimes','numeric','min:0'],
        ]);
        foreach (['logo','favicon'] as $key) {
            if ($request->hasFile($key)) {
                $old = SiteSetting::where('key',$key)->value('value');
                if ($old) Storage::disk('public')->delete($old);
                $data[$key] = $request->file($key)->store('site', 'public');
            }
        }
        foreach ($data as $key => $value) {
            if ($value !== null || in_array($key, ['phone','whatsapp','email'], true)) {
                SiteSetting::updateOrCreate(['key'=>$key], ['value'=>(string)$value, 'type'=>in_array($key,['logo','favicon'])?'file':'text']);
            }
        }
        return $this->index();
    }

    private function formatValue(SiteSetting $setting) { return $setting->type === 'file' && $setting->value ? Storage::disk('public')->url($setting->value) : $setting->value; }
}
