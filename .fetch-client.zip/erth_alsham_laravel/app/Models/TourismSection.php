<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TourismSection extends Model
{
    protected $fillable = ['slug','title','summary','content','icon','sort_order','is_active'];
    protected $casts = ['is_active' => 'boolean'];
}
