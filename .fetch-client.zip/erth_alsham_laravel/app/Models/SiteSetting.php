<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiteSetting extends Model
{
    protected $fillable = ['key','value','type'];
    protected $casts = ['value' => 'string'];
}
