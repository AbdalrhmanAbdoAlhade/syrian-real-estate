<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Property extends Model
{
    use HasFactory;

    protected $fillable = [
        'title','city','district','purpose','price_usd','area','rooms','bathrooms',
        'image','images','description','phone','whatsapp','status','published_at',
    ];

    protected $casts = [
        'images' => 'array', 'price_usd' => 'decimal:2', 'area' => 'decimal:2',
        'published_at' => 'datetime',
    ];

    public function scopePublished($query) { return $query->where('status', 'published'); }
}
