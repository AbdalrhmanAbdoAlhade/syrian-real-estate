<?php

namespace Database\Seeders;

use App\Models\SiteSetting;
use App\Models\TourismSection;
use Illuminate\Database\Seeder;

class SiteSettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            'site_name'=>'إرث الشام','tagline'=>'العقارات والسياحة في سوريا',
            'phone'=>'','whatsapp'=>'','email'=>'','hero_title'=>'ابحث عن منزل أحلامك في دمشق، حلب، اللاذقية وكافة المحافظات',
            'hero_description'=>'سواء كنت مقيماً وتبحث عن شقة للبيع أو للإيجار، أو مغترباً تخطط للعودة والاستثمار السياحي، توفر لك منصة إرث الشام العقارات المناسبة.',
            'about_title'=>'منصة إرث الشام: بوابتك الموثوقة للاستثمار والسكن في سوريا',
            'about_text'=>'تعرّف على منصة إرث الشام وخدماتها العقارية والسياحية.',
            'contact_text'=>'فريق إرث الشام جاهز للرد على استفساراتكم.', 'exchange_rate_syp'=>'15000',
        ];
        foreach ($settings as $key=>$value) SiteSetting::firstOrCreate(['key'=>$key], ['value'=>$value,'type'=>'text']);
        $sections = [
            ['slug'=>'history','title'=>'أبرز المعالم والوجهات السياحية','summary'=>'استكشف المعالم التاريخية والطبيعة السورية.','content'=>'','icon'=>'fa-monument','sort_order'=>1],
            ['slug'=>'legal','title'=>'دليل المغترب لشراء العقار القانوني','summary'=>'إرشادات عامة حول إجراءات شراء العقارات.','content'=>'','icon'=>'fa-file-contract','sort_order'=>2],
            ['slug'=>'hospitality','title'=>'خدمات الاستقبال والضيافة','summary'=>'خدمات الإقامة والتنقل للزوار والمغتربين.','content'=>'','icon'=>'fa-hotel','sort_order'=>3],
        ];
        foreach ($sections as $section) TourismSection::firstOrCreate(['slug'=>$section['slug']], $section + ['is_active'=>true]);
    }
}
