<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { public function up(): void { Schema::create('tourism_sections', function(Blueprint $table) { $table->id(); $table->string('slug')->unique(); $table->string('title'); $table->string('summary',1000)->nullable(); $table->longText('content')->nullable(); $table->string('icon')->nullable(); $table->unsignedInteger('sort_order')->default(0); $table->boolean('is_active')->default(true); $table->timestamps(); }); } public function down(): void { Schema::dropIfExists('tourism_sections'); } };
