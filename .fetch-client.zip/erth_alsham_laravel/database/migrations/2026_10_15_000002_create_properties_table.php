<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
 public function up(): void { Schema::create('properties', function(Blueprint $table) {
  $table->id(); $table->string('title'); $table->string('city')->index(); $table->string('district')->nullable();
  $table->enum('purpose',['بيع','إيجار'])->index(); $table->decimal('price_usd',14,2)->default(0)->index(); $table->decimal('area',10,2)->default(0);
  $table->unsignedSmallInteger('rooms')->default(0); $table->unsignedSmallInteger('bathrooms')->default(0);
  $table->string('image')->nullable(); $table->json('images')->nullable(); $table->text('description');
  $table->string('phone',40)->nullable(); $table->string('whatsapp',40)->nullable(); $table->enum('status',['draft','published','archived'])->default('draft')->index();
  $table->timestamp('published_at')->nullable(); $table->timestamps();
 }); }
 public function down(): void { Schema::dropIfExists('properties'); }
};
