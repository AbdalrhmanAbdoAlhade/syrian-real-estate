# باك إند إرث الشام — Laravel API

Starter backend مبني على حقول الواجهة المرفقة. الملفات مهيأة لتطبيق Laravel 11/12 مع Sanctum.

## 1) التثبيت
```bash
composer require laravel/sanctum
php artisan install:api   # إن لم تكن routes/api.php موجودة أو Sanctum غير مجهز
php artisan migrate
php artisan db:seed --class=SiteSettingSeeder
php artisan storage:link
```
انسخ الملفات إلى مشروع Laravel بنفس المسارات. تأكد من تسجيل middleware alias `admin` في `bootstrap/app.php` (Laravel 11/12):
```php
$middleware->alias(['admin' => \App\Http\Middleware\AdminMiddleware::class]);
```
ثم أنشئ الملف `app/Http/Middleware/AdminMiddleware.php` كما هو موضح أدناه أو استخدم `can:admin` حسب نظام الصلاحيات عندك.

## 2) إنشاء أول أدمن
بعد تسجيل حساب عادي، نفّذ:
```bash
php artisan tinker
$user = App\Models\User::where('email', 'admin@example.com')->first();
$user->role = 'admin'; $user->save();
```
لا تفتح تسجيل الأدمن للعامة. تغيير الرول يتم من السيرفر فقط.

## 3) المصادقة
استخدم Bearer token في `Authorization` بعد استدعاء `/api/auth/login`. للويب المعتمد على نفس النطاق يمكن إعداد Sanctum SPA cookies بدل personal access tokens.

## 4) رفع الصور
أرسل `multipart/form-data` في `image` أو `images[]`. الصور تحفظ على public disk، وتأكد من `php artisan storage:link`.

## 5) ملاحظات دمج الواجهة
- احذف البيانات الوهمية `let properties = [...]` واجلبها من `GET /api/properties`.
- زر «أضف عقارك» الحالي لا يجب أن يسمح بالنشر للمستخدم العادي؛ أخفه أو اعرضه للأدمن فقط. الحماية الحقيقية في API.
- إعدادات الموقع ترجع من `GET /api/site-settings` ويمكن للأدمن تعديلها عبر `PUT /api/admin/site-settings`.
- معدل تحويل SYP الحالي ثابت داخل JavaScript؛ الأفضل جعل سعر الصرف إعدادًا قابلًا للتحديث وعدم اعتباره سعرًا حيًا.
- نصوص الدليل السياحي محفوظة في `tourism_sections` ويمكن تعديلها من لوحة الإدارة أو API الأدمن.

## Endpoints الرئيسية
| Method | Endpoint | صلاحية |
|---|---|---|
| POST | `/api/auth/register` | عام، ينشئ user فقط |
| POST | `/api/auth/login` | عام |
| POST | `/api/auth/logout` | مستخدم مسجل |
| GET | `/api/auth/me` | مستخدم مسجل |
| GET | `/api/properties` | عام، المنشور فقط + فلاتر |
| GET | `/api/properties/{property}` | عام، المنشور فقط |
| POST/PUT/DELETE | `/api/admin/properties...` | admin |
| GET | `/api/site-settings` | عام |
| PUT | `/api/admin/site-settings` | admin |
| GET | `/api/tourism-sections` | عام |
| POST/PUT/DELETE | `/api/admin/tourism-sections...` | admin |
| POST | `/api/contact-messages` | عام، مع validation |
| GET | `/api/admin/contact-messages` | admin |

هذه حزمة أساس قابلة للدمج وليست مشروع Laravel كاملًا؛ اختبرها مع نسخة Laravel وإعدادات المشروع الفعلية قبل النشر.
