<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PropertyController;
use App\Http\Controllers\Api\SiteSettingController;
use App\Http\Controllers\Api\TourismSectionController;
use App\Http\Controllers\Api\ContactMessageController;

Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class,'register'])->middleware('throttle:10,1');
    Route::post('/login', [AuthController::class,'login'])->middleware('throttle:10,1');
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/me', [AuthController::class,'me']);
        Route::post('/logout', [AuthController::class,'logout']);
    });
});

Route::get('/properties', [PropertyController::class,'index']);
Route::get('/properties/{property}', [PropertyController::class,'show']);
Route::get('/site-settings', [SiteSettingController::class,'index']);
Route::get('/tourism-sections', [TourismSectionController::class,'index']);
Route::post('/contact-messages', [ContactMessageController::class,'store'])->middleware('throttle:5,1');

Route::prefix('admin')->middleware(['auth:sanctum','admin'])->group(function () {
    Route::get('/properties', [PropertyController::class,'adminIndex']);
    Route::post('/properties', [PropertyController::class,'store']);
    Route::put('/properties/{property}', [PropertyController::class,'update']);
    Route::post('/properties/{property}', [PropertyController::class,'update']); // دعم multipart في بعض العملاء
    Route::delete('/properties/{property}', [PropertyController::class,'destroy']);
    Route::put('/site-settings', [SiteSettingController::class,'update']);
    Route::get('/tourism-sections', [TourismSectionController::class,'adminIndex']);
    Route::post('/tourism-sections', [TourismSectionController::class,'store']);
    Route::put('/tourism-sections/{tourismSection}', [TourismSectionController::class,'update']);
    Route::delete('/tourism-sections/{tourismSection}', [TourismSectionController::class,'destroy']);
    Route::get('/contact-messages', [ContactMessageController::class,'adminIndex']);
    Route::patch('/contact-messages/{contactMessage}', [ContactMessageController::class,'updateStatus']);
});
