-- ============================================================================
-- sections_media_production_rollback.sql
--
-- Reverses sections_media_production.sql.
--
-- WARNING:
--   * This deletes ALL sections, property/media links, and media rows created
--     after deployment, including any uploaded media records.
--   * It never touches properties.image, any original image file, or any
--     other existing column/data.
--   * It does NOT delete physical files under storage/app/public/properties/
--     media. Remove those manually only after verifying you no longer need
--     them.
--   * MySQL DDL auto-commits. DROP TABLE cannot be rolled back.
--   * The migrations DELETE is transactional.
-- ============================================================================

SET NAMES utf8mb4;

-- DDL: drop children before parents so foreign keys never block the drop.
DROP TABLE IF EXISTS `property_media`;
DROP TABLE IF EXISTS `property_section`;
DROP TABLE IF EXISTS `sections`;

-- Remove only the four migration records added by this deployment.
START TRANSACTION;

DELETE FROM `migrations`
WHERE `migration` IN (
    '2026_10_20_000001_create_sections_table',
    '2026_10_20_000002_create_property_section_table',
    '2026_10_20_000003_create_property_media_table',
    '2026_10_20_000004_backfill_property_media_from_properties_image'
);

COMMIT;

-- Verification: these should return zero rows.
SELECT
    TABLE_NAME
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME IN ('sections', 'property_section', 'property_media');

SELECT
    `migration`,
    `batch`
FROM `migrations`
WHERE `migration` IN (
    '2026_10_20_000001_create_sections_table',
    '2026_10_20_000002_create_property_section_table',
    '2026_10_20_000003_create_property_media_table',
    '2026_10_20_000004_backfill_property_media_from_properties_image'
);
