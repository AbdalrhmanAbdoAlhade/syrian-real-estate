-- Production deployment: social_links
-- Migration: 2026_10_20_000005_create_social_links_table
-- Run once (safe to re-run) as a user with CREATE, INSERT and SELECT privileges.
-- DDL auto-commits in MySQL; the migration-row insert is wrapped in a transaction.

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------------
-- Pre-checks
-- ---------------------------------------------------------------------------
SELECT DATABASE() AS database_name;

SELECT COUNT(*) AS migrations_table_exists
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'migrations';

SELECT TABLE_NAME, ENGINE, TABLE_COLLATION
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'social_links';

SELECT COUNT(*) AS existing_migration_rows
FROM migrations
WHERE migration = '2026_10_20_000005_create_social_links_table';

-- ---------------------------------------------------------------------------
-- Schema
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `social_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(50) NOT NULL,
  `label_ar` varchar(255) DEFAULT NULL,
  `label_en` varchar(255) DEFAULT NULL,
  `url` varchar(2048) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `social_links_is_active_sort_order_index` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Register the migration so a later `php artisan migrate` will not re-run it.
-- All new migrations use the next batch after the current maximum.
-- ---------------------------------------------------------------------------
START TRANSACTION;

SET @next_batch := (
  SELECT COALESCE(MAX(batch), 0) + 1
  FROM migrations
);

INSERT INTO migrations (`migration`, `batch`)
SELECT '2026_10_20_000005_create_social_links_table', @next_batch
FROM DUAL
WHERE NOT EXISTS (
  SELECT 1
  FROM migrations
  WHERE migration = '2026_10_20_000005_create_social_links_table'
);

COMMIT;

-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SHOW CREATE TABLE `social_links`;

SELECT INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS indexed_columns
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'social_links'
GROUP BY INDEX_NAME;

SELECT migration, batch
FROM migrations
WHERE migration = '2026_10_20_000005_create_social_links_table';

SELECT COUNT(*) AS migration_rows
FROM migrations
WHERE migration = '2026_10_20_000005_create_social_links_table';

SELECT COUNT(*) AS social_links_rows
FROM social_links;

-- Optional examples (commented out; replace the placeholder URLs before use):
-- INSERT INTO social_links (platform, label_ar, label_en, url, sort_order, is_active, created_at, updated_at) VALUES
-- ('facebook', 'فيسبوك', 'Facebook', 'https://example.com/facebook', 1, 1, NOW(), NOW()),
-- ('instagram', 'إنستغرام', 'Instagram', 'https://example.com/instagram', 2, 1, NOW(), NOW());
