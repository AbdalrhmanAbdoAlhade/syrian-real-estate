-- ============================================================================
-- sections_media_production.sql
--
-- Production deployment for:
--   - sections (many-to-many with properties)
--   - property_media (multiple images/videos + cover)
--   - legacy properties.image backfill into property_media
--   - Laravel migrations table entries so `php artisan migrate` is a no-op
--
-- USE THIS FILE INSTEAD OF `php artisan migrate`.
--
-- IMPORTANT:
--   * Back up the database AND storage/app/public before running this file.
--   * MySQL DDL (`CREATE TABLE`, `DROP TABLE`) auto-commits and cannot be
--     rolled back. The transaction below covers only the INSERT/DELETE data
--     changes. If a data statement fails, run `ROLLBACK;` manually.
--   * This file does not move, rename, or delete any existing image file.
--   * This file is idempotent: it can be run more than once safely.
--   * The four migration names are inserted with one shared, next batch
--     number so Laravel will not try to run them later.
-- ============================================================================

SET NAMES utf8mb4;

-- ============================================================================
-- PRE-CHECKS (read-only; review the output before continuing)
-- ============================================================================

SELECT
    VERSION() AS mysql_version,
    DATABASE() AS current_database,
    @@character_set_database AS db_charset,
    @@collation_database AS db_collation;

SELECT
    TABLE_NAME,
    ENGINE,
    TABLE_COLLATION
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME IN ('sections', 'property_section', 'property_media')
ORDER BY TABLE_NAME;

SELECT COUNT(*) AS properties_total
FROM properties;

SELECT COUNT(*) AS properties_with_image
FROM properties
WHERE image IS NOT NULL AND TRIM(image) <> '';

SELECT COALESCE(MAX(batch), 0) AS current_max_migration_batch
FROM migrations;

SELECT
    migration,
    batch
FROM migrations
WHERE migration IN (
    '2026_10_20_000001_create_sections_table',
    '2026_10_20_000002_create_property_section_table',
    '2026_10_20_000003_create_property_media_table',
    '2026_10_20_000004_backfill_property_media_from_properties_image'
)
ORDER BY migration;

-- If any of the three tables above already exist, verify their structure with
-- SHOW CREATE TABLE before continuing. CREATE TABLE IF NOT EXISTS will not
-- repair a table that exists with a different structure.

-- ============================================================================
-- DDL: NEW TABLES
--
-- These statements auto-commit. They are guarded with IF NOT EXISTS.
-- There are no ALTER TABLE statements because no existing table is changed.
-- ============================================================================

CREATE TABLE IF NOT EXISTS `sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name_ar` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `property_section` (
  `property_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned NOT NULL,
  UNIQUE KEY `property_section_property_id_section_id_unique` (`property_id`,`section_id`),
  KEY `property_section_section_id_foreign` (`section_id`),
  CONSTRAINT `property_section_property_id_foreign`
    FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE,
  CONSTRAINT `property_section_section_id_foreign`
    FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `property_media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `path` varchar(500) NOT NULL,
  `disk` varchar(50) NOT NULL DEFAULT 'public',
  `mime_type` varchar(100) DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_cover` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `property_media_property_id_path_unique` (`property_id`,`path`),
  KEY `property_media_property_id_sort_order_index` (`property_id`,`sort_order`),
  KEY `property_media_property_id_is_cover_index` (`property_id`,`is_cover`),
  CONSTRAINT `property_media_property_id_foreign`
    FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- DATA CHANGES
--
-- The transaction below covers the backfill and migrations rows only.
-- DDL above has already auto-committed.
-- ============================================================================

START TRANSACTION;

-- Batch number used only for rows that do not already exist.
SET @next_batch := (SELECT COALESCE(MAX(batch), 0) + 1 FROM migrations);

-- Legacy image backfill:
--   * one image media row per non-empty properties.image
--   * does not duplicate an existing (property_id, path)
--   * does not move/rename/delete the original file
--   * preserves the image as cover when the property has no cover yet
--   * if a cover already exists, the legacy image is inserted as non-cover
--     so a property can never end up with two covers
INSERT INTO `property_media` (
    `property_id`,
    `type`,
    `path`,
    `disk`,
    `mime_type`,
    `size`,
    `sort_order`,
    `is_cover`,
    `created_at`,
    `updated_at`
)
SELECT
    p.`id`,
    'image',
    TRIM(p.`image`),
    'public',
    CASE LOWER(
        SUBSTRING_INDEX(
            SUBSTRING_INDEX(
                SUBSTRING_INDEX(TRIM(p.`image`), '?', 1),
                '#',
                1
            ),
            '.',
            -1
        )
    )
        WHEN 'jpg' THEN 'image/jpeg'
        WHEN 'jpeg' THEN 'image/jpeg'
        WHEN 'png' THEN 'image/png'
        WHEN 'webp' THEN 'image/webp'
        WHEN 'avif' THEN 'image/avif'
        WHEN 'gif' THEN 'image/gif'
        ELSE NULL
    END,
    NULL,
    0,
    CASE
        WHEN EXISTS (
            SELECT 1
            FROM `property_media` pm_cover
            WHERE pm_cover.`property_id` = p.`id`
              AND pm_cover.`is_cover` = 1
        ) THEN 0
        ELSE 1
    END,
    COALESCE(p.`created_at`, NOW()),
    COALESCE(p.`updated_at`, p.`created_at`, NOW())
FROM `properties` p
WHERE p.`image` IS NOT NULL
  AND TRIM(p.`image`) <> ''
  AND NOT EXISTS (
      SELECT 1
      FROM `property_media` pm
      WHERE pm.`property_id` = p.`id`
        AND pm.`path` = TRIM(p.`image`)
  );

-- Record the migrations exactly as Laravel would. All four share one batch.
-- The NOT EXISTS guards make this safe to run repeatedly.
INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_10_20_000001_create_sections_table', @next_batch FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM `migrations`
    WHERE `migration` = '2026_10_20_000001_create_sections_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_10_20_000002_create_property_section_table', @next_batch FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM `migrations`
    WHERE `migration` = '2026_10_20_000002_create_property_section_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_10_20_000003_create_property_media_table', @next_batch FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM `migrations`
    WHERE `migration` = '2026_10_20_000003_create_property_media_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_10_20_000004_backfill_property_media_from_properties_image', @next_batch FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM `migrations`
    WHERE `migration` = '2026_10_20_000004_backfill_property_media_from_properties_image'
);

COMMIT;

-- ============================================================================
-- VERIFICATION (read-only)
-- ============================================================================

-- Tables and their collations.
SELECT
    TABLE_NAME,
    ENGINE,
    TABLE_COLLATION
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME IN ('sections', 'property_section', 'property_media')
ORDER BY TABLE_NAME;

-- Row counts.
SELECT
    (SELECT COUNT(*) FROM `sections`) AS sections_count,
    (SELECT COUNT(*) FROM `property_section`) AS property_section_count,
    (SELECT COUNT(*) FROM `property_media`) AS property_media_count,
    (SELECT COUNT(*) FROM `property_media` WHERE `type` = 'image') AS image_media_count,
    (SELECT COUNT(*) FROM `property_media` WHERE `type` = 'video') AS video_media_count;

-- Every property with a legacy image must have exactly one cover.
-- Expect zero rows.
SELECT
    p.`id`,
    p.`image`,
    COUNT(pm.`id`) AS cover_count
FROM `properties` p
LEFT JOIN `property_media` pm
    ON pm.`property_id` = p.`id`
   AND pm.`is_cover` = 1
WHERE p.`image` IS NOT NULL
  AND TRIM(p.`image`) <> ''
GROUP BY p.`id`, p.`image`
HAVING COUNT(pm.`id`) <> 1;

-- No property may have more than one cover. Expect zero rows.
SELECT
    `property_id`,
    COUNT(*) AS covers
FROM `property_media`
WHERE `is_cover` = 1
GROUP BY `property_id`
HAVING COUNT(*) > 1;

-- Every non-empty legacy image must have its matching media row. Expect zero rows.
SELECT
    p.`id`,
    p.`image`
FROM `properties` p
LEFT JOIN `property_media` pm
    ON pm.`property_id` = p.`id`
   AND pm.`path` = TRIM(p.`image`)
WHERE p.`image` IS NOT NULL
  AND TRIM(p.`image`) <> ''
  AND pm.`id` IS NULL;

-- The four migration rows must exist exactly once. Expect four rows.
SELECT
    `migration`,
    `batch`,
    COUNT(*) AS occurrences
FROM `migrations`
WHERE `migration` IN (
    '2026_10_20_000001_create_sections_table',
    '2026_10_20_000002_create_property_section_table',
    '2026_10_20_000003_create_property_media_table',
    '2026_10_20_000004_backfill_property_media_from_properties_image'
)
GROUP BY `migration`, `batch`
ORDER BY `migration`;

-- ============================================================================
-- END
-- ============================================================================
