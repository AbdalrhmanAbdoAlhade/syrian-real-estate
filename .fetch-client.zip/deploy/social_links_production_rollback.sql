-- Production rollback: social_links
-- Removes only the social_links table and its migration row.
-- It does not touch any other table or file.

SET NAMES utf8mb4;

-- Pre-check: show what will be removed.
SELECT TABLE_NAME, ENGINE, TABLE_COLLATION
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'social_links';

SELECT migration, batch
FROM migrations
WHERE migration = '2026_10_20_000005_create_social_links_table';

-- Remove schema.
DROP TABLE IF EXISTS `social_links`;

-- Remove the migration row so Laravel can re-run the migration later if needed.
DELETE FROM migrations
WHERE migration = '2026_10_20_000005_create_social_links_table';

-- Verification: both counts should be 0.
SELECT COUNT(*) AS social_links_tables
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'social_links';

SELECT COUNT(*) AS migration_rows
FROM migrations
WHERE migration = '2026_10_20_000005_create_social_links_table';
